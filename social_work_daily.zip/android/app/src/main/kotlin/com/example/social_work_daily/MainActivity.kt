package com.example.social_work_daily

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
