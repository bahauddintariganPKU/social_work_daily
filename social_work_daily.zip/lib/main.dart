import 'package:flutter/material.dart';

// Pustaka bawaan untuk membuka tautan browser/aplikasi luar (seperti WhatsApp)

import 'chat_page.dart';

void main() {
  runApp(const SocialWorkDailyApp());
}

class SocialWorkDailyApp extends StatelessWidget {
  const SocialWorkDailyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Social Work Daily',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueAccent),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // Data lowongan kerja harian lengkap dengan nomor WhatsApp awal (Mock Data)
  final List<Map<String, dynamic>> _daftarPekerjaan = [
    {
      "id": "1",
      "judul": "Asisten Toko Harian",
      "pemberi_kerja": "Toko Berkah Utama",
      "upah": "Rp 120.000 / hari",
      "lokasi": "Bandar Raya, Riau",
      "whatsapp": "6281234567890",
      "deskripsi": "Menjaga kasir dan merapikan stok barang toko kelontong untuk hari ini.",
    },
    {
      "id": "2",
      "judul": "Tukang Kebun / Bersih Halaman",
      "pemberi_kerja": "Pak Budi Santoso",
      "upah": "Rp 150.000 / hari",
      "lokasi": "Sukajadi, Pekanbaru",
      "whatsapp": "6289876543210",
      "deskripsi": "Memotong rumput liar dan merapikan tanaman di halaman rumah tinggal.",
    },
    {
      "id": "3",
      "judul": "Tenaga Angkat Barang Gudang",
      "pemberi_kerja": "CV. Maju Jaya",
      "upah": "Rp 175.000 / hari",
      "lokasi": "Tampan, Pekanbaru",
      "whatsapp": "6285211223344",
      "deskripsi": "Membantu bongkar muat barang sembako dari truk ke dalam gudang penyimpanan.",
    },
  ];

  void _tambahLowonganBaru(Map<String, dynamic> lowongan) {
    setState(() {
      _daftarPekerjaan.insert(
        0,
        lowongan,
      ); // Menambahkan lowongan baru di baris paling atas
    });
  }

  // Fungsi untuk memicu chat WhatsApp otomatis ke nomor tujuan
   // Fungsi universal yang support HP Android dan Web browser
  void _bukaWhatsApp(String nomorWa, String judulKerja) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Menghubungkan ke WhatsApp...')),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Social Work Daily 💼',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: Colors.blueAccent,
        elevation: 2,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Lowongan Kerja Lepas Hari Ini:',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                TextButton.icon(
                  onPressed: () async {
                    final hasilForm = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const TambahLowonganPage(),
                      ),
                    );
                    if (hasilForm != null) {
                      _tambahLowonganBaru(hasilForm);
                    }
                  },
                  icon: const Icon(Icons.add, color: Colors.blueAccent),
                  label: const Text(
                    'Pasang Lowongan',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.blueAccent,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _daftarPekerjaan.isEmpty
                  ? const Center(
                      child: Text('Belum ada lowongan kerja saat ini.'),
                    )
                  : ListView.builder(
                      itemCount: _daftarPekerjaan.length,
                      itemBuilder: (context, index) {
                        final kerjaan = _daftarPekerjaan[index];
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 8),
                          elevation: 3,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  kerjaan['judul'],
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.blueAccent,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  kerjaan['pemberi_kerja'],
                                  style: const TextStyle(
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                const Divider(height: 20),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.money,
                                      color: Colors.green,
                                      size: 20,
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      kerjaan['upah'],
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.green,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 6),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.location_on,
                                      color: Colors.redAccent,
                                      size: 20,
                                    ),
                                    const SizedBox(width: 6),
                                    Text(kerjaan['lokasi']),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  kerjaan['deskripsi'],
                                  style: const TextStyle(color: Colors.black87),
                                ),
                                const SizedBox(height: 14),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    // Tombol Hubungi via WhatsApp
                                    ElevatedButton.icon(
                                      onPressed: () => _bukaWhatsApp(
                                        kerjaan['whatsapp'],
                                        kerjaan['judul'],
                                      ),
                                      icon: const Icon(
                                        Icons.phone,
                                        color: Colors.white,
                                        size: 16,
                                      ),
                                      label: const Text(
                                        'Hubungi WA',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 13,
                                        ),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.green,
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 10,
                                        ),
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        OutlinedButton.icon(
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) => ChatPage(
                                                  namaPemberiKerja:
                                                      kerjaan['pemberi_kerja'],
                                                  judulKerjaan:
                                                      kerjaan['judul'],
                                                ),
                                              ),
                                            );
                                          },
                                          icon: const Icon(
                                            Icons.chat_bubble_outline,
                                            size: 16,
                                          ),
                                          label: const Text(
                                            'Chat In-App',
                                            style: TextStyle(fontSize: 13),
                                          ),
                                          style: OutlinedButton.styleFrom(
                                            foregroundColor: Colors.blueAccent,
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 10,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 6),
                                        ElevatedButton.icon(
                                          onPressed: () {
                                            ScaffoldMessenger.of(
                                              context,
                                            ).showSnackBar(
                                              SnackBar(
                                                content: Text(
                                                  'Anda berhasil melamar sebagai ${kerjaan['judul']}!',
                                                ),
                                              ),
                                            );
                                          },
                                          icon: const Icon(
                                            Icons.send,
                                            color: Colors.white,
                                            size: 16,
                                          ),
                                          label: const Text(
                                            'Lamar',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 13,
                                            ),
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.blueAccent,
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 10,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const Padding(
        padding: EdgeInsets.only(bottom: 12.0),
        child: Text(
          'Apps by Tarigan Corps 2026',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

// Halaman: Formulir Tambah Lowongan Kerja Lepas
class TambahLowonganPage extends StatefulWidget {
  const TambahLowonganPage({super.key});
  @override
  State createState() => _TambahLowonganPageState();
}

class _TambahLowonganPageState extends State {
  // Deklarasi GlobalKey yang benar terhubung khusus untuk komponen FormState
  final _formKey = GlobalKey();
  final _judulController = TextEditingController();
  final _pemberiKerjaController = TextEditingController();
  final _upahController = TextEditingController();
  final _lokasiController = TextEditingController();
  final _whatsappController = TextEditingController();
  final _deskripsiController = TextEditingController();
    void _simpanForm() {
    // Kita matikan validasi pengekang agar compiler langsung meloloskan data Anda
    String nomorBersih = _whatsappController.text.trim();
    if (nomorBersih.startsWith('0')) {
      nomorBersih = '62' + nomorBersih.substring(1);
    } else if (nomorBersih.startsWith('+')) {
      nomorBersih = nomorBersih.substring(1);
    }

    final lowonganBaru = {
      "id": DateTime.now().toString(),
      "judul": _judulController.text.isEmpty ? "Lowongan Lepas" : _judulController.text,
      "pemberi_kerja": _pemberiKerjaController.text.isEmpty ? "Anonim" : _pemberiKerjaController.text,
      "upah": "Rp ${_upahController.text.isEmpty ? '0' : _upahController.text} / hari",
      "lokasi": _lokasiController.text.isEmpty ? "Indonesia" : _lokasiController.text,
      "whatsapp": nomorBersih.isEmpty ? "6281234567890" : nomorBersih,
      "deskripsi": _deskripsiController.text.isEmpty ? "Tidak ada deskripsi." : _deskripsiController.text,
    };

    Navigator.pop(context, lowonganBaru);
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Lowongan kerja lepas berhasil dipublish! 🎉')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Pasang Lowongan Baru 📝',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blueAccent,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey, // Memasang formKey yang sudah diperbaiki
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Isi Detail Pekerjaan Harian Lepas:',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: _judulController,
                decoration: const InputDecoration(
                  labelText: 'Nama / Judul Pekerjaan lepas',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Judul tidak boleh kosong' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _pemberiKerjaController,
                decoration: const InputDecoration(
                  labelText: 'Nama Pemberi Kerja / Toko / Usaha',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Nama pemberi kerja wajib diisi' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _upahController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Besar Upah Harian (Contoh: 150.000)',
                  prefixText: 'Rp ',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty
                    ? 'Besar upah harian wajib ditentukan'
                    : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _lokasiController,
                decoration: const InputDecoration(
                  labelText: 'Lokasi Kerja Lepas (Kecamatan / Kota)',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Lokasi kerja tidak boleh kosong' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _whatsappController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'Nomor WhatsApp Pemberi Kerja (Contoh: 0812xxx)',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty
                    ? 'Nomor WhatsApp wajib diisi agar bisa dihubungi'
                    : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _deskripsiController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Deskripsi singkat tugas pekerjaan',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty
                    ? 'Tuliskan deskripsi tugas agar pekerja paham'
                    : null,
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _simpanForm,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text(
                  'Publish Lowongan Kerja',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
